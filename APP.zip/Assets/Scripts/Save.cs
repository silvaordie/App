﻿using System.Collections;
using UnityEngine;

[System.Serializable]
public class Save
{
    public static Save current;

    public string desc;
    public float mont;
    public float dur;
    public float Vinicial;

}
